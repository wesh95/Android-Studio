package com.example.wesh9.hw1wesh95;

import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by wesh9 on 9/10/2017.
 */

public class Calculator {
    //prices
    double wheatPrice = 1;
    double whitePrice = 1;
    double beefPrice = 5.5;
    double chickPrice = 5;
    double turkPrice = 5;
    double salPrice = 7.5;
    double vegPrice = 4.5;
    double mushPrice = 1;
    double lettPrice = 0.3;
    double tomPrice = 0.3;
    double pickles = 0.5;
    double mayoPrice = 0;
    double mustPrice = 0;
    //calories
    int wheatCal = 100;
    int whiteCal = 140;
    int beefCal = 240;
    int chickCal = 180;
    int turkCal = 190;
    int salCal = 95;
    int vegCal = 80;
    int mushCal = 60;
    int lettCal = 20;
    int tomCal = 20;
    int pickCal = 30;
    int mayoCal = 100;
    int mustCal = 60;

    double price = 0;
    int cal = 0;

    public void setPrice(String bun,  String meat, ArrayList<String> toppings){
        if(bun.equals("Wheat")){
            price = price + wheatPrice;
        }
        else {
            price = price + whitePrice;
        }
        //meat ifs
        if(meat.equals("Beef")){
            price+= beefPrice;
        }
        else if(meat.equals("Grilled Chicken")){
            price+= chickPrice;
        }
        else if(meat.equals("Salmon")){
            price+= salPrice;
        }
        else if(meat.equals("Veggie")){
            price+= vegPrice;
        }
        else if(meat.equals("Turkey")){
            price+= turkPrice;
        }
        //set toppings
        if(toppings.size() != 0) {
            for (int i = 0; i < toppings.size(); i++) {
                if (toppings.get(i).equals("Mushrooms")) {
                    price += mushPrice;
                } else if (toppings.get(i).equals("Tomato")) {
                    price += tomPrice;
                } else if (toppings.get(i).equals("Mayo")) {
                    price += mayoPrice;
                } else if (toppings.get(i).equals("Lettuce")) {
                    price += lettPrice;
                } else if (toppings.get(i).equals("Pickles")) {
                    price += pickles;
                } else if (toppings.get(i).equals("Mustard")) {
                    price += mustPrice;
                }

            }
        }

    }

    public void setCal(String bun,  String meat, ArrayList<String> toppings){
        if(bun.equals("Wheat")){
            cal = cal + wheatCal;
        }
        else {
            cal = cal + whiteCal;
        }
        //meat ifs
        if(meat.equals("Beef")){
            cal+= beefCal;
        }
        else if(meat.equals("Grilled Chicken")){
            cal+= chickCal;
        }
        else if(meat.equals("Salmon")){
            cal+= salCal;
        }
        else if(meat.equals("Veggie")){
            cal+= vegCal;
        }
        else if(meat.equals("Turkey")){
            cal+= turkCal;
        }
        //set toppings
        if(toppings.size() != 0) {
            for (int i = 0; i < toppings.size(); i++) {
                if (toppings.get(i).equals("Mushrooms")) {
                    cal += mushCal;
                } else if (toppings.get(i).equals("Tomato")) {
                    cal += tomCal;
                } else if (toppings.get(i).equals("Mayo")) {
                    cal += mayoCal;
                } else if (toppings.get(i).equals("Lettuce")) {
                    cal += lettCal;
                } else if (toppings.get(i).equals("Pickles")) {
                    cal += pickCal;
                } else if (toppings.get(i).equals("Mustard")) {
                    cal += mustCal;
                }

            }
        }

    }

    public double getPrice(int num){

        return num*price;

    }

    public int getCal(int num){
        return num*cal;
    }

    public void clear(){
        price = 0;
        cal = 0;
    }




}
