package com.example.wesh9.hw1wesh95;

import java.util.ArrayList;

/**
 * Created by wesh9 on 9/10/2017.
 */

public class Burger {
    String bun = "White";
    String meat;
    ArrayList<String> toppings = new ArrayList<String>();

    public void setBun(String inbun){bun = inbun;}

    public void setMeat(String inmeat){meat = inmeat;}

    public void setToppings(ArrayList<String> tops){toppings = tops;}

    public String getBun(){
        return  bun;
    }

    public String getMeat(){
        return  meat;
    }

    public ArrayList<String> getToppings(){
        return toppings;
    }

    public boolean inTops(String top){
        for(int i = 0; i < toppings.size(); i++){
            if(top.equals(toppings.get(i))){
                return true;
            }
        }
        return false;
    }

}
