package com.example.wesh9.hw1wesh95;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    TextView price;
    TextView calories;
    EditText number;
    RadioButton wheat;
    RadioButton white;
    CheckBox mushrooms;
    CheckBox tomato;
    CheckBox mayo;
    CheckBox lettuce;
    CheckBox pickles;
    CheckBox mustard;
    Spinner meat;
    Burger burger;
    Button calculate;
    Calculator calculator;
    ArrayList<String> toppings = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        price = (TextView)findViewById(R.id.price);
        calories = (TextView)findViewById(R.id.calories);
        number = (EditText)findViewById(R.id.numberText);
        wheat = (RadioButton)findViewById(R.id.wheat);
        white = (RadioButton)findViewById(R.id.white);
        mushrooms = (CheckBox)findViewById(R.id.mushroom);
        tomato = (CheckBox)findViewById(R.id.tomato);
        mayo = (CheckBox)findViewById(R.id.mayo);
        lettuce = (CheckBox)findViewById(R.id.lettuce);
        pickles = (CheckBox)findViewById(R.id.pickles);
        mustard = (CheckBox)findViewById(R.id.Mustard);
        meat = (Spinner) findViewById(R.id.burgerSpinner);
       calculate = (Button) findViewById(R.id.calc);
        white.setChecked(true);

        white.setOnClickListener(this);
        wheat.setOnClickListener(this);
        calculate.setOnClickListener(this);

        burger = new Burger();
        calculator = new Calculator();
    }
    public void onBoxClick(View view){

        if( mushrooms.isChecked() && !burger.inTops("Mushrooms")){
            toppings.add("Mushrooms");
            topCheck(toppings.size());
        }
        if(!mushrooms.isChecked() && burger.inTops("Mushrooms")){
            toppings.remove("Mushrooms");
        }
        if( tomato.isChecked() && !burger.inTops("Tomato")){
            toppings.add("Tomato");
            topCheck(toppings.size());
       }
        if(!tomato.isChecked() && burger.inTops("Tomato")){
            toppings.remove("Tomato");
        }
       if( mayo.isChecked()  && !burger.inTops("Mayo")){
           toppings.add( "Mayo");
           topCheck(toppings.size());
       }
       if(!mayo.isChecked() && burger.inTops("Mayo")){
           toppings.remove("Mayo");
       }
       if( lettuce.isChecked()  && !burger.inTops("Lettuce")){
           toppings.add("Lettuce");
           topCheck(toppings.size());
       }
       if(!lettuce.isChecked() && burger.inTops("Lettuce")){
           toppings.remove("Lettuce");
       }
       if( pickles.isChecked()  && !burger.inTops("Pickles")){
           toppings.add("Pickles");
           topCheck(toppings.size());
       }
       if(!pickles.isChecked() && burger.inTops("Pickles")){
           toppings.remove("Pickles");
       }
       if( mustard.isChecked() && !burger.inTops("Mustard")){
           toppings.add("Mustard");
           topCheck(toppings.size());
       }
       if(!mustard.isChecked() && burger.inTops("Mustard")){
           toppings.remove("Mustard");
       }

        burger.setToppings(toppings);

    }

    @Override
    public void onClick(View view) {
        if(view.getId() == wheat.getId()){
            burger.setBun("Wheat");
        }
        if(view.getId() == white.getId()){
            burger.setBun("White");
        }
        if(view.getId() == calculate.getId()){
            update();
        }

    }
    private void topCheck(int num){
        if(num >= 4){
            Toast.makeText(this, "Redo Checkboxes. You can only have 3 toppings", Toast.LENGTH_SHORT).show();
            mushrooms.setChecked(false);
            tomato.setChecked(false);
            mayo.setChecked(false);
            lettuce.setChecked(false);
            pickles.setChecked(false);
            mustard.setChecked(false);
            toppings.clear();
        }

    }

    private void update(){
        burger.setMeat(meat.getSelectedItem().toString());
        calculator.setCal(burger.getBun(), burger.getMeat(), burger.getToppings());
        calculator.setPrice(burger.getBun(), burger.getMeat(), burger.getToppings());
        if(number.getText().toString().equals("") || Integer.parseInt(number.getText().toString()) > 10){
            Toast.makeText(this, "Enter a different number of burgers", Toast.LENGTH_SHORT).show();
        }
        else {
            double priceTotal = calculator.getPrice(Integer.parseInt(number.getText().toString()));
            int calTotal = calculator.getCal(Integer.parseInt(number.getText().toString()));
            DecimalFormat df = new DecimalFormat("#.00");
            String money = df.format(priceTotal);

            calories.setText(Integer.toString(calTotal) + "cals");
            price.setText("$" + money);
            calculator.clear();


        }


    }



}
